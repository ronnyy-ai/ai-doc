package com.example.demo.util;


public class MRZValidator {

    // Weights for the MRZ check digit calculation
    private static final int[] WEIGHTS = {7, 3, 1};

    /**
     * Validates an MRZ string by checking its check digits.
     *
     * @param mrz The MRZ string to validate.
     * @return true if the MRZ is valid, false otherwise.
     */
    public static boolean validateMRZ(String mrz) {
        try {
            // Clean and normalize the MRZ data
            String cleanedMrz = mrz.replace(" ", "").replace("\n", "");

            // Ensure the MRZ is exactly 88 characters (2 lines of 44 characters)
            if (cleanedMrz.length() != 88) {
                throw new IllegalArgumentException("Invalid MRZ data length");
            }

            // Extract fields from the combined MRZ
            String documentNumber = cleanedMrz.substring(44, 53); // Document number
            char documentNumberCheckDigit = cleanedMrz.charAt(53);

            String dateOfBirth = cleanedMrz.substring(57, 63); // Date of birth
            char dateOfBirthCheckDigit = cleanedMrz.charAt(63);

            String dateOfExpiry = cleanedMrz.substring(65, 71); // Date of expiry
            char dateOfExpiryCheckDigit = cleanedMrz.charAt(71);

            // Validate each field using the calculateCheckDigit method
            return calculateCheckDigit(documentNumber) == Character.getNumericValue(documentNumberCheckDigit)
                    && calculateCheckDigit(dateOfBirth) == Character.getNumericValue(dateOfBirthCheckDigit)
                    && calculateCheckDigit(dateOfExpiry) == Character.getNumericValue(dateOfExpiryCheckDigit);
        } catch (Exception e) {
            // Handle invalid MRZ format
            return false;
        }
    }

    /**
     * Calculates the check digit for a given MRZ field.
     *
     * @param field The MRZ field to calculate the check digit for.
     * @return The calculated check digit.
     */
    private static int calculateCheckDigit(String field) {
        int sum = 0;
        for (int i = 0; i < field.length(); i++) {
            char c = field.charAt(i);
            int value = getCharacterValue(c);
            sum += value * WEIGHTS[i % WEIGHTS.length];
        }
        return sum % 10;
    }

    /**
     * Maps a character to its numeric value for MRZ calculation.
     *
     * @param c The character to map.
     * @return The numeric value of the character.
     */
    private static int getCharacterValue(char c) {
        if (c >= '0' && c <= '9') {
            return c - '0'; // Numeric characters
        } else if (c >= 'A' && c <= 'Z') {
            return c - 'A' + 10; // Alphabetic characters
        } else if (c == '<') {
            return 0; // '<' maps to 0
        } else {
            throw new IllegalArgumentException("Invalid character in MRZ: " + c);
        }
    }
}