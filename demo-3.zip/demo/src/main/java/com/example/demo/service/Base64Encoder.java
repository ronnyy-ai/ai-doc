/*
package com.example.demo.service;

import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Base64;

public class Base64Encoder {
    public static void main(String[] args) throws Exception {
        // Read the file
        byte[] fileBytes = Files.readAllBytes(Paths.get("C:/Users/Ravi/Downloads/test/success7.png"));

        // Encode the file to Base64
        String base64EncodedFile = Base64.getEncoder().encodeToString(fileBytes);
        System.out.println("Base64 Encoded File:");
        System.out.println(base64EncodedFile);

        // Save the file for debugging
        Base64Encoder encoder = new Base64Encoder();
        encoder.saveFileForDebugging(fileBytes, "C:/Users/Ravi/Downloads/test/debug_success7.png");
    }

    private void saveFileForDebugging(byte[] fileBytes, String fileName) {
        try (FileOutputStream fos = new FileOutputStream(fileName)) {
            fos.write(fileBytes);
            System.out.println("File saved for debugging: " + fileName);
        } catch (IOException e) {
            System.out.println("Failed to save file for debugging: " + e.getMessage());
        }
    }
}*/
