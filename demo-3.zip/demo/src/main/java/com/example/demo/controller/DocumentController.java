package com.example.demo.controller;

import com.example.demo.model.OcrResponse;
import com.example.demo.service.DocumentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/documents")
public class DocumentController {

    @Autowired
    private DocumentService documentService;
    @Operation(summary = "Analyze a document using a file upload")
    @ApiResponse(responseCode = "200", description = "Document analyzed successfully")
    @ApiResponse(responseCode = "500", description = "Error analyzing document")
    @PostMapping("/analyze")
    public ResponseEntity<String> analyzeDocument(@RequestParam("files") MultipartFile files) {
        try {
            String result = documentService.analyzeDocument(files).toString();
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error analyzing document: " + e.getMessage());
        }
    }
    @Operation(summary = "Analyze a document using a file upload")
    @ApiResponse(responseCode = "200", description = "Document analyzed successfully",
            content = @io.swagger.v3.oas.annotations.media.Content(
                    mediaType = "application/json",
                    schema = @io.swagger.v3.oas.annotations.media.Schema(implementation = OcrResponse.class)
            ))
    @ApiResponse(responseCode = "500", description = "Error analyzing document")
    @PostMapping("/analyze1")
    public ResponseEntity<OcrResponse> analyzeDocument1(@RequestBody String files) {

            OcrResponse result = documentService.analyzeDocument1(files);
            return ResponseEntity.ok(result);

    }
    
}
