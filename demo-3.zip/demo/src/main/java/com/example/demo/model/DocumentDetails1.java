package com.example.demo.model;



public class DocumentDetails1 {
    private String dateOfIssue;
    private String firstName;
    private String countryRegion;
    private String documentType;
    private String lastName;
    private String documentNumber;
    private String izData;
    private String nationality;
    private String placeOfIssue;
    private String placeOfBirth;
    private String dateOfExpiration;

    // Getters and Setters
    public String getDateOfIssue() {
        return dateOfIssue;
    }

    public void setDateOfIssue(String dateOfIssue) {
        this.dateOfIssue = dateOfIssue;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getCountryRegion() {
        return countryRegion;
    }

    public void setCountryRegion(String countryRegion) {
        this.countryRegion = countryRegion;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getDocumentNumber() {
        return documentNumber;
    }

    public void setDocumentNumber(String documentNumber) {
        this.documentNumber = documentNumber;
    }

    public String getIzData() {
        return izData;
    }

    public void setIzData(String izData) {
        this.izData = izData;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String getPlaceOfIssue() {
        return placeOfIssue;
    }

    public void setPlaceOfIssue(String placeOfIssue) {
        this.placeOfIssue = placeOfIssue;
    }

    public String getPlaceOfBirth() {
        return placeOfBirth;
    }

    public void setPlaceOfBirth(String placeOfBirth) {
        this.placeOfBirth = placeOfBirth;
    }

    public String getDateOfExpiration() {
        return dateOfExpiration;
    }

    public void setDateOfExpiration(String dateOfExpiration) {
        this.dateOfExpiration = dateOfExpiration;
    }

    @Override
    public String toString() {
        return "DocumentDetails{" +
                "dateOfIssue='" + dateOfIssue + '\'' +
                ", firstName='" + firstName + '\'' +
                ", countryRegion='" + countryRegion + '\'' +
                ", documentType='" + documentType + '\'' +
                ", lastName='" + lastName + '\'' +
                ", documentNumber='" + documentNumber + '\'' +
                ", izData='" + izData + '\'' +
                ", nationality='" + nationality + '\'' +
                ", placeOfIssue='" + placeOfIssue + '\'' +
                ", placeOfBirth='" + placeOfBirth + '\'' +
                ", dateOfExpiration='" + dateOfExpiration + '\'' +
                '}';
    }
}