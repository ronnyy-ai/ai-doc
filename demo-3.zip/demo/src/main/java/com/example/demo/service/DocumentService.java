package com.example.demo.service;

import com.azure.ai.formrecognizer.documentanalysis.DocumentAnalysisClient;
import com.azure.ai.formrecognizer.documentanalysis.DocumentAnalysisClientBuilder;
import com.azure.ai.formrecognizer.documentanalysis.models.AnalyzeResult;
import com.azure.ai.formrecognizer.documentanalysis.models.DocumentField;
import com.azure.core.credential.AzureKeyCredential;
import com.azure.core.util.BinaryData;
import com.example.demo.exception.OcrProcessingException;
import com.example.demo.model.DocumentDetails1;
import com.example.demo.model.OcrResponse;
import com.example.demo.util.MRZValidator;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import net.minidev.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class DocumentService {

    private static final Logger logger = LoggerFactory.getLogger(DocumentService.class);
    private static final long MAX_FILE_SIZE = 4 * 1024 * 1024; // 4MB

    @Value("${azure.document.key}")
    private String apiKey;

    @Value("${azure.document.endpoint}")
    private String endpoint;

    public OcrResponse analyzeDocument(MultipartFile file) {
        validateImage(file);

        try {
            DocumentAnalysisClient client = new DocumentAnalysisClientBuilder()
                    .credential(new AzureKeyCredential(apiKey))
                    .endpoint(endpoint)
                    .buildClient();

            byte[] fileBytes = file.getBytes();
            AnalyzeResult classifyResult = client.beginClassifyDocument("09082025", BinaryData.fromBytes(fileBytes))
                    .getFinalResult();

            // Check the result of the classification
            if (isGoodImageType(classifyResult)) {
                AnalyzeResult analyzeResult = client.beginAnalyzeDocument("data_test_ind_pak", BinaryData.fromBytes(fileBytes))
                        .getFinalResult();
                /*List<String> lines = analyzeResult.getPages().stream()
                        .flatMap(page -> page.getLines().stream())
                        .map(line -> line.getContent())
                        .collect(Collectors.toList());*/
                Map<String, Object> extractedFields = new HashMap<>();
                List<String> lines = analyzeResult.getPages().stream()
                        .flatMap(page -> page.getLines().stream())
                        .map(line -> line.getContent())
                        .collect(Collectors.toList());

                // Add lines content to the extracted fields
                extractedFields.put("LinesContent", lines);

                // Add other fields if needed
                extractedFields.put("DocumentNumber", analyzeResult.getDocuments().stream()
                        .filter(doc -> doc.getFields().containsKey("DocumentNumber"))
                        .map(doc -> doc.getFields().get("DocumentNumber").getContent())
                        .findFirst().orElse(null));

                if (lines.isEmpty()) {
                    logger.warn("No text detected in the document");
                    return OcrResponse.error("No text detected in the document");
                } else {
                    logger.info("Successfully processed document, found {} lines of text", lines.size());
                    return OcrResponse.success((List<String>) extractedFields.get("LinesContent"));
                }
            } else {
                logger.warn("Image type is not good");
                return OcrResponse.error("Image type is not good");
            }
        } catch (Exception e) {
             logger.error("Failed to process document", e);
            throw new OcrProcessingException("Failed to process document: " + e.getMessage(), e);
        }
    }

    private boolean isGoodImageType(AnalyzeResult classifyResult) {
        return classifyResult.getDocuments().stream()
                .anyMatch(document -> "good".equals(document.getDocType()));
        // return true;
    }

    private void validateImage(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new OcrProcessingException("Document file is required");
        }
        if (file.getSize() > MAX_FILE_SIZE) {
            throw new OcrProcessingException("File size exceeds maximum limit of 4MB");
        }
        String contentType = file.getContentType();
        if (contentType == null || !contentType.startsWith("image/")) {
            throw new OcrProcessingException("Invalid file type. Only image files are allowed");
        }
    }



    public OcrResponse analyzeDocument1(String base64File) throws OcrProcessingException {
        validateBase64String(base64File);

        try {
            // Decode Base64 string to byte array
            byte[] fileBytes = Base64.getDecoder().decode(base64File);

            DocumentAnalysisClient client = new DocumentAnalysisClientBuilder()
                    .credential(new AzureKeyCredential(apiKey))
                    .endpoint(endpoint)
                    .buildClient();

            AnalyzeResult classifyResult = client.beginClassifyDocument("09082025", BinaryData.fromBytes(fileBytes))
                    .getFinalResult();

            if (isGoodImageType1(classifyResult)) {
                AnalyzeResult analyzeResult = client.beginAnalyzeDocument("data_test_ind_pak", BinaryData.fromBytes(fileBytes))
                        .getFinalResult();

                // Configure ObjectMapper with JavaTimeModule
                ObjectMapper objectMapper = new ObjectMapper();
                objectMapper.registerModule(new JavaTimeModule());
                objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);

                // Extract fields manually
                String documentNumber = analyzeResult.getDocuments().stream()
                        .filter(doc -> doc.getFields().containsKey("DocumentNumber"))
                        .map(doc -> doc.getFields().get("DocumentNumber").getContent())
                        .findFirst().orElse(null);

                String izData = analyzeResult.getDocuments().stream()
                        .filter(doc -> doc.getFields().containsKey("MIZData"))
                        .map(doc -> doc.getFields().get("MIZData").getContent())
                        .findFirst().orElse(null);

                String FirstName = analyzeResult.getDocuments().stream()
                        .filter(doc -> doc.getFields().containsKey("FirstName"))
                        .map(doc -> doc.getFields().get("FirstName").getContent())
                        .findFirst().orElse(null);

                String PlaceOfBirth = analyzeResult.getDocuments().stream()
                        .filter(doc -> doc.getFields().containsKey("PlaceOfBirth"))
                        .map(doc -> doc.getFields().get("PlaceOfBirth").getContent())
                        .findFirst().orElse(null);
                String Nationality = analyzeResult.getDocuments().stream()
                        .filter(doc -> doc.getFields().containsKey("Nationality"))
                        .map(doc -> doc.getFields().get("Nationality").getContent())
                        .findFirst().orElse(null);
                String CountryRegion = analyzeResult.getDocuments().stream()
                        .filter(doc -> doc.getFields().containsKey("CountryRegion"))
                        .map(doc -> doc.getFields().get("CountryRegion").getContent())
                        .findFirst().orElse(null);
                String LastName = analyzeResult.getDocuments().stream()
                        .filter(doc -> doc.getFields().containsKey("LastName"))
                        .map(doc -> doc.getFields().get("LastName").getContent())
                        .findFirst().orElse(null);
                String PlaceOfIssue = analyzeResult.getDocuments().stream()
                        .filter(doc -> doc.getFields().containsKey("PlaceOfIssue"))
                        .map(doc -> doc.getFields().get("PlaceOfIssue").getContent())
                        .findFirst().orElse(null);
                String DocumentType = analyzeResult.getDocuments().stream()
                        .filter(doc -> doc.getFields().containsKey("DocumentType"))
                        .map(doc -> doc.getFields().get("DocumentType").getContent())
                        .findFirst().orElse(null);

                String DateOfExpiration = analyzeResult.getDocuments().stream()
                        .filter(doc -> doc.getFields().containsKey("DateOfExpiration"))
                        .map(doc -> {

                            DocumentField dateField = doc.getFields().get("DateOfExpiration");
                            if (dateField.getValue() instanceof LocalDate) {
                                return ((LocalDate) dateField.getValue()).toString(); // Convert LocalDate to String
                            }
                            return dateField.getContent(); // Fallback to content if not LocalDate
                        })
                        .findFirst().orElse(null);
                String DateOfIssue = analyzeResult.getDocuments().stream()
                        .filter(doc -> doc.getFields().containsKey("DateOfIssue"))
                        .map(doc -> {

                            DocumentField dateField = doc.getFields().get("DateOfIssue");
                            if (dateField.getValue() instanceof LocalDate) {
                                return ((LocalDate) dateField.getValue()).toString(); // Convert LocalDate to String
                            }
                            return dateField.getContent(); // Fallback to content if not LocalDate
                        })
                        .findFirst().orElse(null);
                // Handle LocalDate for DateOfBirth
                String dateOfBirth = analyzeResult.getDocuments().stream()
                        .filter(doc -> doc.getFields().containsKey("DateOfBirth"))
                        .map(doc -> {

                            DocumentField dateField = doc.getFields().get("DateOfBirth");
                            if (dateField.getValue() instanceof LocalDate) {
                                return ((LocalDate) dateField.getValue()).toString(); // Convert LocalDate to String
                            }
                            return dateField.getContent(); // Fallback to content if not LocalDate
                        })
                        .findFirst().orElse(null);
                boolean isValid = MRZValidator.validateMRZ(izData);
                if (!isValid) {
                    throw new OcrProcessingException("MRZ data is invalid");
                }
                Map<String, String> extractedFields = new HashMap<>();
                extractedFields.put("DocumentNumber", documentNumber);
                extractedFields.put("IZData", izData);
                extractedFields.put("PlaceOfBirth", PlaceOfBirth);
                extractedFields.put("dateOfBirth", dateOfBirth);
                extractedFields.put("FirstName", FirstName);
                extractedFields.put("Nationality", Nationality);
                extractedFields.put("CountryRegion", CountryRegion);
                extractedFields.put("LastName", LastName);
                extractedFields.put("PlaceOfIssue", PlaceOfIssue);
                extractedFields.put("DocumentType", DocumentType);
                extractedFields.put("DateOfExpiration", DateOfExpiration);
                extractedFields.put("DateOfIssue", DateOfIssue);

                logger.info("Extracted fields: {}", extractedFields);

                // Adjust response to match OcrResponse.success
                DocumentDetails1 documentDetails = new DocumentDetails1();
                documentDetails.setDateOfIssue(extractedFields.get("DateOfIssue"));
                documentDetails.setFirstName(extractedFields.get("FirstName"));
                documentDetails.setCountryRegion(extractedFields.get("CountryRegion"));
                documentDetails.setDocumentType(extractedFields.get("DocumentType"));
                documentDetails.setLastName(extractedFields.get("LastName"));
                documentDetails.setDocumentNumber(extractedFields.get("DocumentNumber"));
                documentDetails.setIzData(extractedFields.get("IZData"));
                documentDetails.setNationality(extractedFields.get("Nationality"));
                documentDetails.setPlaceOfIssue(extractedFields.get("PlaceOfIssue"));
                documentDetails.setPlaceOfBirth(extractedFields.get("PlaceOfBirth"));
                documentDetails.setDateOfExpiration(extractedFields.get("DateOfExpiration"));

                OcrResponse response = OcrResponse.success(
                        extractedFields.entrySet().stream()
                                .map(entry -> entry.getKey() + ": " + entry.getValue())
                                .collect(Collectors.toList())
                );
                response.setDocumentDetails(documentDetails);

                return response;
            } else {
                logger.warn("Image type is not good");
                return OcrResponse.error("Image type is not good");
            }
        } catch (Exception e) {
            logger.error("Failed to process document", e);
            throw new OcrProcessingException("Failed to process document: " + e.getMessage(), e);
        }
    }

    private void validateBase64String(String base64File) {
        if (base64File == null || base64File.isEmpty()) {
            throw new OcrProcessingException("Base64 string is required");
        }
        // Optionally, you can add further validation for Base64 format
    }
    private boolean isGoodImageType1(AnalyzeResult classifyResult) {
        return classifyResult.getDocuments().stream()
                .anyMatch(document -> "good".equals(document.getDocType()));
        // return true;
    }
}