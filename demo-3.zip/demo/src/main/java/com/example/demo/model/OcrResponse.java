package com.example.demo.model;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

public class OcrResponse {
    private boolean success;
    private List<String> lines;
    private String errorMessage;

    @Getter
    @Setter
    private DocumentDetails1 documentDetails;

    public static OcrResponse success(List<String> lines) {
        OcrResponse response = new OcrResponse();
        response.success = true;
        response.lines = lines;

        return response;
    }

    public static OcrResponse error(String errorMessage) {
        OcrResponse response = new OcrResponse();
        response.success = false;
        response.errorMessage = errorMessage;
        return response;
    }

    @Override
    public String toString() {
        return "OcrResponse{" +
                "success=" + success +
             //   ", lines=" + lines +
                ", documentDetails=" + documentDetails +
                ", errorMessage='" + errorMessage + '\'' +
                '}';
    }

    // Getters and setters
}